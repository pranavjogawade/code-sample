## Yarn version

Yarn version is set using `yarn-path` in `.yarnrc`. To update to the latest version:

1. Run
```shell
yarn policies set-version latest
```
2. Remove the old version from `.yarn/releases`
