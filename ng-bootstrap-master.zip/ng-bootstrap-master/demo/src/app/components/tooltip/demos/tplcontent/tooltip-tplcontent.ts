import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tooltip-tplcontent',
  templateUrl: './tooltip-tplcontent.html'
})
export class NgbdTooltipTplcontent {
  name = 'World';
}
