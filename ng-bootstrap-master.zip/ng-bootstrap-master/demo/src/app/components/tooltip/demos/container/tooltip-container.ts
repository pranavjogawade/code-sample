import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tooltip-container',
  templateUrl: './tooltip-container.html',
  styles: ['.card { overflow:hidden }']
})
export class NgbdTooltipContainer {
}
