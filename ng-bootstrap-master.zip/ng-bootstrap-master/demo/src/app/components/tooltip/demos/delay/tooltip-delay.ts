import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tooltip-delay',
  templateUrl: './tooltip-delay.html'
})
export class NgbdTooltipDelay {
}
