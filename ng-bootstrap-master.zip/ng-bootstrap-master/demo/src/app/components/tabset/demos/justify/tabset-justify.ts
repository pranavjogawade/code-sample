import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tabset-justify',
  templateUrl: './tabset-justify.html'
})
export class NgbdTabsetJustify {
  currentJustify = 'start';
 }
