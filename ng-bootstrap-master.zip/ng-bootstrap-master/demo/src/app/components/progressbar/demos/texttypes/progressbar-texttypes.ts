import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-progressbar-texttypes',
  templateUrl: './progressbar-texttypes.html'
})
export class NgbdProgressbarTextTypes {
}
