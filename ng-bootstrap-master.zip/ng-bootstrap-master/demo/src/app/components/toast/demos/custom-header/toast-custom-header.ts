import { Component } from '@angular/core';

@Component({ selector: 'ngbd-toast-customheader', templateUrl: './toast-custom-header.html' })
export class NgbdToastCustomHeader {}
