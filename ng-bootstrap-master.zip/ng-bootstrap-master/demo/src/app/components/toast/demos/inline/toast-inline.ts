import { Component } from '@angular/core';

@Component({ selector: 'ngbd-toast-inline', templateUrl: './toast-inline.html' })
export class NgbdToastInline {}
