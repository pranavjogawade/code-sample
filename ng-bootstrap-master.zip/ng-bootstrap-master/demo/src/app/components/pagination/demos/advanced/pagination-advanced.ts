import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-pagination-advanced',
  templateUrl: './pagination-advanced.html'
})
export class NgbdPaginationAdvanced {
  page = 1;
}
