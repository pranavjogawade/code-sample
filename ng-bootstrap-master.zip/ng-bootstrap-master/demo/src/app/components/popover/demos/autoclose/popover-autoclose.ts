import {Component} from '@angular/core';



@Component({
  selector: 'ngbd-popover-autoclose',
  templateUrl: './popover-autoclose.html'
})
export class NgbdPopoverAutoclose {}
