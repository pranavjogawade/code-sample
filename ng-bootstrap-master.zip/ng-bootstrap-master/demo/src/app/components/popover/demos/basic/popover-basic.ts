import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-popover-basic',
  templateUrl: './popover-basic.html'
})
export class NgbdPopoverBasic {
}
