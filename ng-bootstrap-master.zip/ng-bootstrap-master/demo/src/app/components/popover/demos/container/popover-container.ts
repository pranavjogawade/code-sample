import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-popover-container',
  templateUrl: './popover-container.html',
  styles: ['.card { overflow: hidden }']
})
export class NgbdPopoverContainer {
}
