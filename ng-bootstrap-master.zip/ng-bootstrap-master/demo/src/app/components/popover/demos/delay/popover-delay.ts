import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-popover-delay',
  templateUrl: './popover-delay.html'
})
export class NgbdPopoverDelay {
}
