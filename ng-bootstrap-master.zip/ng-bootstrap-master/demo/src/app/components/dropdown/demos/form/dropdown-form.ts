import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-dropdown-form',
  templateUrl: './dropdown-form.html'
})
export class NgbdDropdownForm {
}
