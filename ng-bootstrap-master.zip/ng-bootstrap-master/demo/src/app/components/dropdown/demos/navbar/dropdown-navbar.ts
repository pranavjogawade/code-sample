import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-dropdown-navbar',
  templateUrl: './dropdown-navbar.html'
})
export class NgbdDropdownNavbar {
  collapsed = true;
}
