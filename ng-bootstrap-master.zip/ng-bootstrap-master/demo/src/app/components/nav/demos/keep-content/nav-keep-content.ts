import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-nav-keep',
  templateUrl: './nav-keep-content.html'
})
export class NgbdNavKeep {
  active = 1;
}
