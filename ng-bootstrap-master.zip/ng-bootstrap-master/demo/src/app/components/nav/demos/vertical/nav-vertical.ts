import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-nav-vertical',
  templateUrl: './nav-vertical.html'
})
export class NgbdNavVertical {
  active = 'top';
}
