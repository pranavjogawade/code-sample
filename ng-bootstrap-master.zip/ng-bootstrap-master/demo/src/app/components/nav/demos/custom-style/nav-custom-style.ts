import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-nav-custom-style',
  templateUrl: './nav-custom-style.html'
})
export class NgbdNavCustomStyle { }
