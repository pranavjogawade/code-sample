import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-nav-markup',
  templateUrl: './nav-markup.html'
})
export class NgbdNavMarkup { }
