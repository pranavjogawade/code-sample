import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-nav-basic',
  templateUrl: './nav-basic.html'
})
export class NgbdNavBasic {
  active = 1;
}
