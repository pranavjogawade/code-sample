import { versions } from './versions';

export const environment = {
  production: true,
  version: versions.ngBootstrap,
  bootstrap: versions.bootstrap
};
